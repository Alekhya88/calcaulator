# CPP-Quiz
A quiz program in CPP and C with Graphics
This program will be having a 4 levels.
Each level will have a cutt off mark to go to next level.
The questions will be in a random order.
